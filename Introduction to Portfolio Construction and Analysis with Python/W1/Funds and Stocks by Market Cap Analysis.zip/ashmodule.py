import pandas as pd
import numpy as np
import scipy.stats
import matplotlib as plt

def drawdown(ret_ser: pd.Series):
    """
    Lets Calculate it:
    1. Compute wealth index
    2. Compute previous peaks
    3. Compute Drawdown - which is the wealth value as a percentage of the previous peak
    """
    wealth_index = 1000*(1+ret_ser).cumprod()
    prev_peak = wealth_index.cummax()
    draw_down = (wealth_index-prev_peak)/prev_peak
    return pd.DataFrame({
        "Wealth Index": wealth_index,
        "Previous Peak": prev_peak,
        "Drawdown" : draw_down        
    })


def all_pfme():
    """
    This Function reads all data in the Portfolios_Formed_on_ME_monthly_EW file.
    """
    pfme_df = pd.read_csv("data/Portfolios_Formed_on_ME_monthly_EW.csv", index_col=0 , na_values=-99.99, parse_dates= True)
    pfme_df.index = pd.to_datetime(pfme_df.index, format="%Y%m")
    pfme_df.index = pfme_df.index.to_period('M')
    pfme_df = pfme_df/100
    return pfme_df

def get_ffme_returns():
    """
    This Function only reads the Large Cap and Small Cap (Hi 10 and Lo 10) in the Portfolios_Formed_on_ME_monthly_EW file.
    """
    rets = pd.read_csv("data/Portfolios_Formed_on_ME_monthly_EW.csv", index_col=0 , na_values=-99.99, parse_dates= True)
    rets = rets[['Lo 10','Hi 10']]
    rets.columns = ['SmallCap', 'LargeCap']
    rets.index = pd.to_datetime(rets.index, format="%Y%m")
    rets.index = rets.index.to_period('M')
    rets = rets/100
    return rets

def get_hfi_returns():
    """
    This Function reads Hedge Fund indecies only
    """
    hfi = pd.read_csv("data/edhec-hedgefundindices.csv", index_col=0 , na_values=-99.99, parse_dates= True)
    hfi.index = hfi.index.to_period('M')
    hfi = hfi/100
    return hfi


def semideviation(r):
    """
    Returns the semi-deviation (Negative Deviation) , 
    
 
    """
    demeaned_r = r - r.mean()
    sigma_r = r.std(ddof=0)
    exp = (demeaned_r**3).mean()
    q_sig = (sigma_r**3)
    skw = exp/q_sig
    return skw
def skewness(r):
    """
    Alternative to Scipy Skewness (scipy.skew()), 
    This one calculate Skewness of a Series or DF and return Float or Series of Floats
    Calculation depends on population STD (N) not sample STD (n-1) 
    """
    demeaned_r = r - r.mean()
    sigma_r = r.std(ddof=0)
    exp = (demeaned_r**3).mean()
    q_sig = (sigma_r**3)
    skw = exp/q_sig
    return skw

def kurt(r):
    """
    Alternative to Scipy Kurtosis (scipy.kurtosis()), 
    This one calculate Kurtosis of a Series or DF and return Float or Series of Floats
    Calculation depends on population STD (N) not sample STD (n-1) 
    The Kurtosis is not the variance of normality, to calculate variance justify it with -3 or justify scipy with +3 
    """
    demeaned_r = r - r.mean()
    sigma_r = r.std(ddof=0)
    exp = (demeaned_r**4).mean()
    q_sig = (sigma_r**4)
    k = exp/q_sig
    return k

def is_normal(r , level = 0.1):
    """
    Applies Jarque-Bera test to determine if the dataseries is normally distributed
    Test applied with default value of 1%
    Returns True if hypothesis of being normal accepted
    """
    statistic, p_value=scipy.stats.jarque_bera(r)
    return p_value > level